<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: request_blood.php');
    exit;
}

$donor_id = (int)($_POST['donor_id'] ?? 0);
$blood_group = $_POST['blood_group'] ?? '';
$request_contact = $_POST['request_contact'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM donors WHERE id = ?");
$stmt->execute([$donor_id]);
$donor = $stmt->fetch();

$message = '';
if (!$donor) {
    $message = "Donor not found.";
} else {
    $to = $donor['email'] ?: null;
    $phone = $donor['phone'];

    // Compose a message (simple)
    $subject = "Urgent: Blood donation request for $blood_group";
    $body = "Hello {$donor['name']},\n\nAn urgent blood request for blood group $blood_group has been registered.\nContact: $request_contact\n\nIf you can help, please respond immediately.\n\nThank you,\nBlood Bank Alert System";

    // Option 1: send email (requires configured mail server)
    $sentEmail = false;
    if ($to) {
        // NOTE: mail() may not work on local dev without SMTP configured.
        $headers = "From: no-reply@yourdomain.com\r\nReply-To: no-reply@yourdomain.com";
        $sentEmail = @mail($to, $subject, $body, $headers);
    }

    // Option 2: (fallback) show simulated SMS / email and mark as sent in DB or just display
    $message = "Prepared alert for {$donor['name']} (Phone: {$phone}, Email: {$donor['email']}). ";
    if ($to) {
        $message .= $sentEmail ? "Email sent." : "Email not sent (mail not configured) — show message below.";
    } else {
        $message .= "No email on file. Please call at $phone.";
    }
    $message .= "\n\nMessage body:\n" . $body;
}

?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Send Alert</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
  <header><h1>Send Alert</h1><nav><a href="index.php">Home</a> | <a href="request_blood.php">Back</a></nav></header>

  <pre style="white-space:pre-wrap; background:#f3f4f6; padding:12px; border-radius:6px;"><?=htmlspecialchars($message)?></pre>

  <p><strong>Note:</strong> This demo uses <code>mail()</code> which usually needs SMTP configured. For production, configure an SMTP server or use PHPMailer / external provider (SendGrid, Mailgun).</p>
</div>
</body>
</html>

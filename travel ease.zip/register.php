<?php
require 'db.php';
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $blood_group = $_POST['blood_group'] ?? '';
    $city = trim($_POST['city'] ?? '');
    $last_donation = $_POST['last_donation'] ?? null;

    if ($name === '' || $blood_group === '') {
        $errors[] = "Name and blood group are required.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO donors (name, email, phone, blood_group, city, last_donation, is_available) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([$name, $email, $phone, $blood_group, $city, $last_donation ?: null]);
        $success = "Thanks $name — you're registered as a donor.";
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Register as Donor</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
  <header><h1>Donor Registration</h1><nav><a href="index.php">Home</a></nav></header>

  <?php if($errors): ?>
    <div class="alert"><?=implode('<br>',$errors)?></div>
  <?php endif; ?>
  <?php if($success): ?>
    <div class="alert" style="border-left-color: #10b981; background:#ecfdf5;"><?=htmlspecialchars($success)?></div>
  <?php endif; ?>

  <form method="post">
    <div class="input-row">
      <div>
        <label>Name *</label><input type="text" name="name" required>
      </div>
      <div>
        <label>Blood Group *</label>
        <select name="blood_group" required>
          <option value="">Select</option>
          <?php foreach (['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg) echo "<option value=\"$bg\">$bg</option>"; ?>
        </select>
      </div>
    </div>

    <div class="input-row">
      <div><label>Email</label><input type="email" name="email"></div>
      <div><label>Phone</label><input type="text" name="phone"></div>
    </div>

    <div class="input-row">
      <div><label>City</label><input type="text" name="city"></div>
      <div><label>Last donation date</label><input type="date" name="last_donation"></div>
    </div>

    <button type="submit">Register</button>
  </form>
</div>
</body>
</html>

<?php
require 'db.php';
session_start();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        header('Location: admin_dashboard.php');
        exit;
    } else {
        $error = 'Invalid credentials.';
    }
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Admin Login</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container">
<header><h1>Admin Login</h1></header>
<?php if($error): ?><div class="alert"><?=$error?></div><?php endif; ?>
<form method="post">
  <div class="input-row">
    <div><label>Username</label><input type="text" name="username" required></div>
    <div><label>Password</label><input type="password" name="password" required></div>
  </div>
  <button type="submit">Login</button>
</form>
</div>
</body></html>

<?php
require 'db.php';
session_start();
if (empty($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// handle toggle availability or delete
if (isset($_POST['toggle_id'])) {
    $id = (int)$_POST['toggle_id'];
    $stmt = $pdo->prepare("UPDATE donors SET is_available = 1 - is_available WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: admin_dashboard.php');
    exit;
}
if (isset($_POST['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM donors WHERE id = ?");
    $stmt->execute([(int)$_POST['delete_id']]);
    header('Location: admin_dashboard.php');
    exit;
}

$donors = $pdo->query("SELECT * FROM donors ORDER BY created_at DESC")->fetchAll();
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Admin</title><link rel="stylesheet" href="style.css"></head><body>
<div class="container">
<header><h1>Admin Dashboard</h1><nav><a href="index.php">Home</a></nav></header>

<h3>Registered donors (<?=count($donors)?>)</h3>
<table class="table">
  <tr><th>Name</th><th>Blood</th><th>City</th><th>Phone</th><th>Email</th><th>Available</th><th>Actions</th></tr>
  <?php foreach($donors as $d): ?>
    <tr>
      <td><?=htmlspecialchars($d['name'])?></td>
      <td><?=htmlspecialchars($d['blood_group'])?></td>
      <td><?=htmlspecialchars($d['city'])?></td>
      <td><?=htmlspecialchars($d['phone'])?></td>
      <td><?=htmlspecialchars($d['email'])?></td>
      <td><?= $d['is_available'] ? 'Yes' : 'No' ?></td>
      <td>
        <form method="post" style="display:inline;">
          <input type="hidden" name="toggle_id" value="<?= (int)$d['id'] ?>">
          <button type="submit" class="secondary"><?= $d['is_available'] ? 'Mark Unavailable' : 'Mark Available' ?></button>
        </form>
        <form method="post" style="display:inline;">
          <input type="hidden" name="delete_id" value="<?= (int)$d['id'] ?>">
          <button type="submit" onclick="return confirm('Delete donor?')">Delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
</table>

</div>
</body></html>

<?php
require 'db.php';
$errors = [];
$matches = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_name = trim($_POST['patient_name'] ?? '');
    $blood_group = $_POST['blood_group'] ?? '';
    $units_needed = (int)($_POST['units_needed'] ?? 1);
    $city = trim($_POST['city'] ?? '');
    $contact_phone = trim($_POST['contact_phone'] ?? '');
    $contact_email = trim($_POST['contact_email'] ?? '');

    if ($blood_group === '') $errors[] = "Please choose a blood group.";

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO blood_requests (patient_name, blood_group, units_needed, city, contact_phone, contact_email) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$patient_name, $blood_group, $units_needed, $city, $contact_phone, $contact_email]);
        $request_id = $pdo->lastInsertId();
        $success = "Request recorded (ID: $request_id). Searching for matching donors...";

        // find donors: same blood group, available, optionally same city
        if ($city !== '') {
            $stmt = $pdo->prepare("SELECT * FROM donors WHERE blood_group = ? AND is_available = 1 AND city = ? ORDER BY created_at DESC");
            $stmt->execute([$blood_group, $city]);
        } else {
            // if no city specified, return donors anywhere
            $stmt = $pdo->prepare("SELECT * FROM donors WHERE blood_group = ? AND is_available = 1 ORDER BY created_at DESC");
            $stmt->execute([$blood_group]);
        }
        $matches = $stmt->fetchAll();
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Request Blood</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="container">
  <header><h1>Request Blood (Emergency)</h1><nav><a href="index.php">Home</a></nav></header>

  <?php if($errors): ?><div class="alert"><?=implode('<br>',$errors)?></div><?php endif; ?>
  <?php if($success): ?><div class="alert"><?=$success?></div><?php endif; ?>

  <form method="post">
    <div class="input-row">
      <div><label>Patient name</label><input type="text" name="patient_name"></div>
      <div>
        <label>Blood Group *</label>
        <select name="blood_group" required>
          <option value="">Select</option>
          <?php foreach (['A+','A-','B+','B-','O+','O-','AB+','AB-'] as $bg) echo "<option value=\"$bg\">$bg</option>"; ?>
        </select>
      </div>
    </div>

    <div class="input-row">
      <div><label>Units needed</label><input type="number" name="units_needed" min="1" value="1"></div>
      <div><label>City</label><input type="text" name="city" placeholder="Optional - helps narrow search"></div>
    </div>

    <div class="input-row">
      <div><label>Contact phone</label><input type="text" name="contact_phone"></div>
      <div><label>Contact email</label><input type="email" name="contact_email"></div>
    </div>

    <button type="submit">Create Request & Find Donors</button>
  </form>

  <?php if($matches): ?>
    <h3>Matching donors (<?=count($matches)?>)</h3>
    <table class="table">
      <tr><th>Name</th><th>Blood</th><th>City</th><th>Phone</th><th>Email</th><th>Action</th></tr>
      <?php foreach($matches as $d): ?>
        <tr>
          <td><?=htmlspecialchars($d['name'])?></td>
          <td><?=htmlspecialchars($d['blood_group'])?></td>
          <td><?=htmlspecialchars($d['city'])?></td>
          <td><?=htmlspecialchars($d['phone'])?></td>
          <td><?=htmlspecialchars($d['email'])?></td>
          <td>
            <!-- send_alert.php will actually send (or simulate) the alert -->
            <form method="post" action="send_alert.php" style="display:inline;">
              <input type="hidden" name="donor_id" value="<?= (int)$d['id'] ?>">
              <input type="hidden" name="blood_group" value="<?=htmlspecialchars($blood_group)?>">
              <input type="hidden" name="request_contact" value="<?=htmlspecialchars($contact_phone . ' | ' . $contact_email)?>">
              <button type="submit">Send Alert</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
  <?php elseif($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
    <p>No matching donors found. Consider widening the search (remove city) or contact nearby blood banks.</p>
  <?php endif; ?>

</div>
</body>
</html>

<?php
// index.php
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Blood Bank & Donor Alert</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<header>
  <h1>Blood Bank & Emergency Donor Alert</h1>
  <nav>
    <a href="register.php">Register as Donor</a>
    <a href="request_blood.php">Request Blood (Emergency)</a>
    <a href="admin_login.php">Admin</a>
  </nav>
</header>

<p>Quick: register as a donor, or create an emergency blood request — the system will show matching donors to alert.</p>

</div>
</body>
</html>
